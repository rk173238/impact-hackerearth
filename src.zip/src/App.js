import logo from './logo.svg';
import './App.css';
import Main from './Container/Main';

function App() {
  return (
    <div className="App">
      <Main></Main>
    </div>
  );
}

export default App;
